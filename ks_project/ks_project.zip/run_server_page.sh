#! /bin/bash
echo "==============================="
echo "= KICKSTARTER DATA COLLECTION ="
echo "==============================="
echo "=           2014              ="
echo "=       SERVER SCRIPT         ="
echo "==============================="
anaconda ks_page_server.py
